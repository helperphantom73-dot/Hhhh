package com.lingoworld.app.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val LocalNeonPalette = compositionLocalOf { BluePalette }

@Composable
fun LingoWorldTheme(
    themeKey: String = "neon-blue",
    content: @Composable () -> Unit
) {
    val target = paletteFor(themeKey)

    // Colors cross-fade smoothly when the user switches theme.
    val bg by animateColorAsState(target.bg, tween<Color>(700), label = "ThemeBg")
    val primary by animateColorAsState(target.primary, tween<Color>(700), label = "ThemePrimary")
    val secondary by animateColorAsState(target.secondary, tween<Color>(700), label = "ThemeSecondary")
    val tertiary by animateColorAsState(target.tertiary, tween<Color>(700), label = "ThemeTertiary")

    val palette = NeonPalette(target.key, target.label, bg, primary, secondary, tertiary)
    val colorScheme = darkColorScheme(
        primary = primary,
        secondary = secondary,
        tertiary = tertiary,
        background = bg,
        surface = bg,
        onPrimary = bg,
        onBackground = TextPrimary,
        onSurface = TextPrimary
    )

    // Default app direction is Right-to-Left (Persian)
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalNeonPalette provides palette
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
