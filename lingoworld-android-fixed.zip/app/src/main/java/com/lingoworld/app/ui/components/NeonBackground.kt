package com.lingoworld.app.ui.components

import android.content.Context
import android.os.PowerManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.lingoworld.app.ui.theme.LocalNeonPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val TWO_PI = (2.0 * PI).toFloat()

private data class Star(val x: Float, val y: Float, val r: Float, val k: Int, val off: Float)

@Composable
private fun rememberPowerSaveMode(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        pm?.isPowerSaveMode ?: false
    }
}

@Composable
fun NeonBackground(
    modifier: Modifier = Modifier,
    isLowPowerMode: Boolean = rememberPowerSaveMode()
) {
    val palette = LocalNeonPalette.current

    val stars = remember {
        val rnd = Random(7)
        List(34) {
            Star(
                x = rnd.nextFloat(),
                y = rnd.nextFloat(),
                r = 0.7f + rnd.nextFloat() * 1.5f,
                k = 3 + rnd.nextInt(6),
                off = rnd.nextFloat()
            )
        }
    }

    // One slow clock drives everything; integer multiples keep the loop seamless.
    val transition = rememberInfiniteTransition(label = "NeonClock")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "NeonPhase"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        // Reading the state here (draw phase) redraws without recomposing.
        val t = if (isLowPowerMode) 0f else phase
        val w = this.size.width
        val h = this.size.height
        val d = this.size.maxDimension

        drawRect(color = palette.bg)

        fun orb(color: Color, cx: Float, cy: Float, radius: Float, alpha: Float) {
            val c = Offset(cx, cy)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color.copy(alpha = alpha), Color.Transparent),
                    center = c,
                    radius = radius
                ),
                radius = radius,
                center = c
            )
        }

        // Orb 1: primary (drifts in a gentle ellipse)
        orb(
            palette.primary,
            w * 0.2f + sin(TWO_PI * t) * w * 0.09f,
            h * 0.18f + cos(TWO_PI * t) * h * 0.03f,
            d * 0.35f, 0.42f
        )
        // Orb 2: secondary
        orb(
            palette.secondary,
            w * 0.85f + sin(TWO_PI * (t * 2f + 0.3f)) * w * 0.05f,
            h * 0.30f + cos(TWO_PI * t) * h * 0.05f,
            d * 0.40f, 0.38f
        )
        // Orb 3: tertiary (skipped in power-save mode)
        if (!isLowPowerMode) {
            orb(
                palette.tertiary,
                w * 0.5f + cos(TWO_PI * t) * w * 0.15f,
                h * 0.78f + sin(TWO_PI * (t * 2f)) * h * 0.04f,
                d * 0.36f, 0.34f
            )

            // Twinkling stars
            for (s in stars) {
                val tw = 0.5f + 0.5f * sin(TWO_PI * (t * s.k + s.off))
                drawCircle(
                    color = Color.White.copy(alpha = 0.12f + 0.55f * tw),
                    radius = s.r * density,
                    center = Offset(s.x * w, s.y * h)
                )
            }
        }
    }
}
