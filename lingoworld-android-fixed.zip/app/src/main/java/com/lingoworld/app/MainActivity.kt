package com.lingoworld.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lingoworld.app.ui.components.NeonBackground
import com.lingoworld.app.ui.screens.home.HomeScreen
import com.lingoworld.app.ui.screens.onboarding.OnboardingScreen
import com.lingoworld.app.ui.theme.LingoWorldTheme
import com.lingoworld.app.ui.theme.TextPrimary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val profile by vm.profile.collectAsState()

    LingoWorldTheme(themeKey = profile.theme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Transparent,
            contentColor = TextPrimary
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                NeonBackground()

                // Wait for DataStore so returning users never see a flash of onboarding.
                if (profile.loaded) {
                    AnimatedContent(
                        targetState = profile.onboardingDone,
                        transitionSpec = { fadeIn(tween(600)) togetherWith fadeOut(tween(300)) },
                        label = "RootSwitch"
                    ) { done ->
                        if (done) {
                            HomeScreen(vm)
                        } else {
                            OnboardingScreen(
                                onComplete = { name, age, level, interests ->
                                    vm.completeOnboarding(name, age, level, interests)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
