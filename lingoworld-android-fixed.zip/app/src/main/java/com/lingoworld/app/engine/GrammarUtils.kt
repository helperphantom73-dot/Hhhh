package com.lingoworld.app.engine

import com.lingoworld.app.data.model.IrregularForms

object GrammarUtils {
    private const val VOWELS = "aeiou"

    private val silentHPrefixes = listOf("hour", "honest", "honor", "honour", "heir")
    private val consonantSoundPrefixes = listOf("uni", "use", "usu", "uti", "uto", "eu", "one", "once", "ubi")

    private val irregularPlurals = mapOf(
        "man" to "men", "woman" to "women", "child" to "children",
        "foot" to "feet", "tooth" to "teeth", "mouse" to "mice",
        "person" to "people", "goose" to "geese"
    )
    private val unchangedPlurals = setOf("sheep", "fish", "deer", "series", "species")
    private val fToVes = setOf(
        "leaf", "wolf", "half", "shelf", "loaf", "thief", "calf", "self", "elf",
        "knife", "life", "wife"
    )
    private val oEs = setOf("potato", "tomato", "hero", "echo", "volcano")

    /** Phonetic a/an determination based on sound, not just letters. */
    fun getIndefiniteArticle(word: String): String {
        val clean = word.trim().lowercase()
        if (clean.isEmpty()) return "a"

        if (silentHPrefixes.any { clean.startsWith(it) }) return "an"
        if (clean.startsWith("unim") || clean.startsWith("unin")) return "an"
        if (consonantSoundPrefixes.any { clean.startsWith(it) }) return "a"

        return if (clean[0] in VOWELS) "an" else "a"
    }

    /** Pluralization rules with irregular lookup. */
    fun pluralize(noun: String): String {
        val lower = noun.lowercase()
        irregularPlurals[lower]?.let { return it }
        if (lower in unchangedPlurals) return noun

        if (lower in fToVes) {
            return if (lower.endsWith("fe")) noun.dropLast(2) + "ves" else noun.dropLast(1) + "ves"
        }
        if (lower in oEs) return noun + "es"

        if (lower.length > 1 && lower.endsWith("y") && lower[lower.length - 2] !in VOWELS) {
            return noun.dropLast(1) + "ies"
        }
        if (listOf("s", "sh", "ch", "x", "z").any { lower.endsWith(it) }) {
            return noun + "es"
        }
        return noun + "s"
    }

    /** 3rd-person singular inflection. */
    fun conjugate3sg(verb: String): String {
        val lower = verb.lowercase()
        if (lower == "have") return "has"
        if (lower == "be") return "is"
        if (lower == "do") return "does"
        if (lower == "go") return "goes"
        if (lower == "quiz") return verb + "zes"

        if (lower.length > 1 && lower.endsWith("y") && lower[lower.length - 2] !in VOWELS) {
            return verb.dropLast(1) + "ies"
        }
        if (listOf("s", "sh", "ch", "x", "z", "o").any { lower.endsWith(it) }) {
            return verb + "es"
        }
        return verb + "s"
    }

    /** Simple past: irregular lookup first, then regular -ed rules. */
    fun pastTense(verb: String, irregular: IrregularForms? = null): String {
        irregular?.let { return it.past }
        val lower = verb.lowercase()
        return when {
            lower.endsWith("e") -> verb + "d"
            lower.length > 1 && lower.endsWith("y") && lower[lower.length - 2] !in VOWELS ->
                verb.dropLast(1) + "ied"
            else -> verb + "ed"
        }
    }
}
