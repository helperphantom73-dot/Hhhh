package com.lingoworld.app.data

import com.lingoworld.app.data.model.IrregularForms
import com.lingoworld.app.data.model.PersianVerbForms
import com.lingoworld.app.data.model.Template
import com.lingoworld.app.data.model.Word

/** Built-in offline content. Use '_' where a Persian half-space (ZWNJ) is needed. */
object SampleData {

    private fun zw(s: String) = s.replace('_', '\u200c')

    private fun noun(
        id: String, en: String, fa: String, phonetic: String,
        topics: List<String>, tags: List<String>, countable: Boolean = true
    ) = Word(
        id = id, en = en, fa = zw(fa), pos = "noun", level = "A1", topics = topics,
        phonetic = phonetic, countable = countable, tags = tags
    )

    private fun verb(
        id: String, en: String, fa: String, phonetic: String,
        topics: List<String>,
        p1: String, p3: String, s1: String, s3: String,
        accepts: List<String> = emptyList(),
        irregular: IrregularForms? = null
    ) = Word(
        id = id, en = en, fa = zw(fa), pos = "verb", level = "A1", topics = topics,
        phonetic = phonetic, irregular = irregular, acceptsObjectTags = accepts,
        faForms = PersianVerbForms(zw(p1), zw(p3), zw(s1), zw(s3))
    )

    private val cooking = listOf("cooking")
    private val travel = listOf("travel")
    private val tech = listOf("tech")
    private val sports = listOf("sports")
    private val music = listOf("music")
    private val nature = listOf("nature")

    val words: List<Word> = listOf(
        // ---------- Nouns ----------
        noun("n_apple", "apple", "سیب", "ˈæp.əl", cooking, listOf("food")),
        noun("n_bread", "bread", "نان", "bred", cooking, listOf("food"), countable = false),
        noun("n_soup", "soup", "سوپ", "suːp", cooking, listOf("food")),
        noun("n_egg", "egg", "تخم_مرغ", "eɡ", cooking, listOf("food")),
        noun("n_cake", "cake", "کیک", "keɪk", cooking, listOf("food")),
        noun("n_onion", "onion", "پیاز", "ˈʌn.jən", cooking, listOf("food")),
        noun("n_rice", "rice", "برنج", "raɪs", cooking, listOf("food"), countable = false),

        noun("n_city", "city", "شهر", "ˈsɪt.i", travel, listOf("place")),
        noun("n_beach", "beach", "ساحل", "biːtʃ", travel, listOf("place")),
        noun("n_museum", "museum", "موزه", "mjuːˈziː.əm", travel, listOf("place")),
        noun("n_hotel", "hotel", "هتل", "hoʊˈtel", travel, listOf("place")),
        noun("n_airport", "airport", "فرودگاه", "ˈer.pɔːrt", travel, listOf("place")),
        noun("n_mountain", "mountain", "کوه", "ˈmaʊn.tən", listOf("travel", "nature"), listOf("place", "nature")),
        noun("n_ticket", "ticket", "بلیت", "ˈtɪk.ɪt", travel, listOf("item")),
        noun("n_suitcase", "suitcase", "چمدان", "ˈsuːt.keɪs", travel, listOf("item")),
        noun("n_map", "map", "نقشه", "mæp", travel, listOf("item")),

        noun("n_phone", "phone", "گوشی", "foʊn", tech, listOf("gadget")),
        noun("n_laptop", "laptop", "لپ_تاپ", "ˈlæp.tɑːp", tech, listOf("gadget")),
        noun("n_app", "app", "برنامه", "æp", tech, listOf("gadget")),
        noun("n_camera", "camera", "دوربین", "ˈkæm.rə", tech, listOf("gadget")),
        noun("n_robot", "robot", "ربات", "ˈroʊ.bɑːt", tech, listOf("gadget")),
        noun("n_keyboard", "keyboard", "صفحه_کلید", "ˈkiː.bɔːrd", tech, listOf("gadget")),

        noun("n_game", "game", "بازی", "ɡeɪm", sports, listOf("event")),
        noun("n_match", "match", "مسابقه", "mætʃ", sports, listOf("event")),
        noun("n_race", "race", "مسابقه_ی دو", "reɪs", sports, listOf("event")),
        noun("n_team", "team", "تیم", "tiːm", sports, listOf("person")),
        noun("n_coach", "coach", "مربی", "koʊtʃ", sports, listOf("person")),
        noun("n_ball", "ball", "توپ", "bɔːl", sports, listOf("item")),

        noun("n_song", "song", "آهنگ", "sɔːŋ", music, listOf("playable")),
        noun("n_guitar", "guitar", "گیتار", "ɡɪˈtɑːr", music, listOf("playable", "instrument")),
        noun("n_piano", "piano", "پیانو", "piˈæn.oʊ", music, listOf("playable", "instrument")),
        noun("n_drum", "drum", "طبل", "drʌm", music, listOf("playable", "instrument")),
        noun("n_album", "album", "آلبوم", "ˈæl.bəm", music, listOf("playable", "item")),
        noun("n_concert", "concert", "کنسرت", "ˈkɑːn.sɚt", music, listOf("event")),

        noun("n_tree", "tree", "درخت", "triː", nature, listOf("nature")),
        noun("n_river", "river", "رودخانه", "ˈrɪv.ɚ", nature, listOf("nature", "place")),
        noun("n_flower", "flower", "گل", "ˈflaʊ.ɚ", nature, listOf("nature")),
        noun("n_bird", "bird", "پرنده", "bɝːd", nature, listOf("nature")),
        noun("n_lake", "lake", "دریاچه", "leɪk", nature, listOf("nature", "place")),
        noun("n_forest", "forest", "جنگل", "ˈfɔːr.ɪst", nature, listOf("nature", "place")),

        // ---------- Verbs ----------
        verb("v_cook", "cook", "پختن", "kʊk", cooking,
            "می_پزم", "می_پزد", "پختم", "پخت", accepts = listOf("food")),
        verb("v_eat", "eat", "خوردن", "iːt", cooking,
            "می_خورم", "می_خورد", "خوردم", "خورد", accepts = listOf("food"),
            irregular = IrregularForms("ate", "eaten")),
        verb("v_buy", "buy", "خریدن", "baɪ", listOf("cooking", "travel", "tech", "sports", "music"),
            "می_خرم", "می_خرد", "خریدم", "خرید",
            accepts = listOf("food", "item", "gadget", "instrument"),
            irregular = IrregularForms("bought", "bought")),
        verb("v_like", "like", "دوست داشتن", "laɪk",
            listOf("cooking", "travel", "tech", "sports", "music", "nature"),
            "دوست دارم", "دوست دارد", "دوست داشتم", "دوست داشت"),
        verb("v_love", "love", "خیلی دوست داشتن", "lʌv",
            listOf("cooking", "travel", "sports", "music", "nature"),
            "خیلی دوست دارم", "خیلی دوست دارد", "خیلی دوست داشتم", "خیلی دوست داشت"),
        verb("v_visit", "visit", "بازدید کردن", "ˈvɪz.ɪt", listOf("travel", "nature"),
            "بازدید می_کنم", "بازدید می_کند", "بازدید کردم", "بازدید کرد",
            accepts = listOf("place")),
        verb("v_see", "see", "دیدن", "siː", listOf("travel", "sports", "nature"),
            "می_بینم", "می_بیند", "دیدم", "دید",
            irregular = IrregularForms("saw", "seen")),
        verb("v_find", "find", "پیدا کردن", "faɪnd", listOf("travel", "tech", "nature"),
            "پیدا می_کنم", "پیدا می_کند", "پیدا کردم", "پیدا کرد",
            irregular = IrregularForms("found", "found")),
        verb("v_use", "use", "استفاده کردن", "juːz", tech,
            "استفاده می_کنم", "استفاده می_کند", "استفاده کردم", "استفاده کرد",
            accepts = listOf("gadget")),
        verb("v_need", "need", "نیاز داشتن", "niːd", listOf("travel", "tech", "sports"),
            "نیاز دارم", "نیاز دارد", "نیاز داشتم", "نیاز داشت"),
        verb("v_want", "want", "خواستن", "wɑːnt", listOf("travel", "tech", "sports"),
            "می_خواهم", "می_خواهد", "خواستم", "خواست"),
        verb("v_watch", "watch", "تماشا کردن", "wɑːtʃ", listOf("sports", "music", "nature"),
            "تماشا می_کنم", "تماشا می_کند", "تماشا کردم", "تماشا کرد",
            accepts = listOf("event", "nature")),
        verb("v_hear", "hear", "شنیدن", "hɪr", music,
            "می_شنوم", "می_شنود", "شنیدم", "شنید",
            accepts = listOf("playable"),
            irregular = IrregularForms("heard", "heard")),
        verb("v_play", "play", "نواختن", "pleɪ", music,
            "می_نوازم", "می_نوازد", "نواختم", "نواخت",
            accepts = listOf("playable"))
    )

    val templates: List<Template> = listOf(
        Template(
            id = "a1_i", level = "A1",
            pattern = "I {V} {ART} {O}.",
            faPattern = zw("من {ART} {O} {FV1}."),
            grammarTopic = "زمان حال ساده"
        ),
        Template(
            id = "a1_3sg", level = "A1",
            pattern = "She {V:3sg} {ART} {O}.",
            faPattern = zw("او {ART} {O} {FV3}."),
            grammarTopic = "سوم شخص مفرد (s / es)"
        ),
        Template(
            id = "a1_be", level = "A1",
            pattern = "This is {ART} {O}.",
            faPattern = zw("این {ART} {O} است."),
            grammarTopic = "فعل to be"
        ),
        Template(
            id = "a2_past1", level = "A2",
            pattern = "Yesterday, I {V:past} {ART} {O}.",
            faPattern = zw("دیروز من {ART} {O} {FP1}."),
            grammarTopic = "گذشته ساده"
        ),
        Template(
            id = "a2_past3", level = "A2",
            pattern = "He {V:past} {ART} {O} last week.",
            faPattern = zw("او هفته_ی گذشته {ART} {O} {FP3}."),
            grammarTopic = "گذشته ساده (افعال بی‌قاعده)"
        )
    )
}
