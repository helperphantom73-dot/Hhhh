package com.lingoworld.app.ui.screens.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.AppViewModel
import com.lingoworld.app.R
import com.lingoworld.app.engine.GeneratedSentence
import com.lingoworld.app.tts.SpeechHelper
import com.lingoworld.app.ui.components.BubbleButton
import com.lingoworld.app.ui.components.GlassCard
import com.lingoworld.app.ui.components.LumoState
import com.lingoworld.app.ui.components.LumoView
import com.lingoworld.app.ui.theme.AllPalettes
import com.lingoworld.app.ui.theme.LocalNeonPalette
import com.lingoworld.app.util.toFaDigits
import kotlinx.coroutines.delay

private val cheers = listOf("آفرین! 🎉", "عالی بود!", "همین‌طور ادامه بده!", "تو فوق‌العاده‌ای ✨")

@Composable
fun HomeScreen(vm: AppViewModel) {
    val profile by vm.profile.collectAsState()
    val sentence by vm.sentence.collectAsState()
    val palette = LocalNeonPalette.current
    val context = LocalContext.current

    // Offline text-to-speech
    var ttsMissing by remember { mutableStateOf(false) }
    val speech = remember { SpeechHelper(context) { ttsMissing = true } }
    DisposableEffect(speech) { onDispose { speech.shutdown() } }

    // Lumo's mood: celebrates on success, "thinks" while a new sentence is prepared
    var lumoState by remember { mutableStateOf(LumoState.HAPPY) }
    var lumoText by remember { mutableStateOf("سلام ${profile.name}! بیا یه جمله‌ی جدید یاد بگیریم") }
    var moodTick by remember { mutableIntStateOf(0) }
    var moodDelayMs by remember { mutableIntStateOf(2400) }

    LaunchedEffect(Unit) {
        if (vm.sentence.value == null) vm.nextSentence()
        delay(3200)
        if (moodTick == 0) {
            lumoState = LumoState.IDLE
            lumoText = ""
        }
    }
    LaunchedEffect(moodTick) {
        if (moodTick > 0) {
            delay(moodDelayMs.toLong())
            lumoState = LumoState.IDLE
            lumoText = ""
        }
    }

    var showTranslation by remember(sentence?.id) { mutableStateOf(false) }
    var learned by remember(sentence?.id) { mutableStateOf(false) }

    val xpShown by animateIntAsState(
        targetValue = profile.xp,
        animationSpec = tween(800),
        label = "XpCounter"
    )
    val levelNumber = profile.xp / 100 + 1
    val levelProgress by animateFloatAsState(
        targetValue = (profile.xp % 100) / 100f,
        animationSpec = tween(800),
        label = "XpProgress"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---- Level / XP ----
        GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سطح ${levelNumber.toFaDigits()}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${xpShown.toFaDigits()} XP",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = palette.primary
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(levelProgress.coerceIn(0.03f, 1f))
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(Brush.horizontalGradient(listOf(palette.primary, palette.secondary)))
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Lumo grows an antenna at level 2 and beyond
        LumoView(
            state = lumoState,
            stage = if (levelNumber >= 2) 2 else 1,
            size = 150.dp,
            speechText = lumoText.ifEmpty { null }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // ---- Sentence card ----
        GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 24.dp) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AnimatedContent(
                    targetState = sentence,
                    transitionSpec = {
                        (fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 8 }) togetherWith
                            (fadeOut(tween(200)) + slideOutVertically(tween(200)) { -it / 8 })
                    },
                    label = "SentenceSwap"
                ) { s ->
                    SentenceText(s)
                }

                AnimatedVisibility(
                    visible = showTranslation && sentence != null,
                    enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                    exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = sentence?.fa ?: "",
                            fontSize = 18.sp,
                            color = palette.primary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        if (ttsMissing) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.offline_tts_error),
                fontSize = 12.sp,
                color = Color(0xFFFFC857),
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ---- Actions ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BubbleButton(
                text = "🔊 شنیدن",
                enabled = sentence != null,
                onClick = {
                    sentence?.let { speech.speak(it.audioText, profile.ttsSpeed) }
                },
                modifier = Modifier.weight(1f)
            )
            BubbleButton(
                text = if (showTranslation) "پنهان‌کردن ترجمه" else "نمایش ترجمه",
                enabled = sentence != null,
                outlined = true,
                onClick = { showTranslation = !showTranslation },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BubbleButton(
                text = "جمله‌ی بعدی",
                outlined = true,
                onClick = {
                    lumoState = LumoState.THINKING
                    lumoText = "یه جمله‌ی جدید..."
                    moodDelayMs = 900
                    moodTick += 1
                    vm.nextSentence()
                },
                modifier = Modifier.weight(1f)
            )
            BubbleButton(
                text = if (learned) "✓ ثبت شد" else "یاد گرفتم  +${AppViewModel.XP_PER_SENTENCE.toFaDigits()}",
                enabled = sentence != null && !learned,
                onClick = {
                    learned = true
                    vm.markLearned()
                    lumoState = LumoState.CELEBRATE
                    lumoText = cheers.random()
                    moodDelayMs = 2400
                    moodTick += 1
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ---- Theme picker ----
        Text(text = "تم برنامه", fontSize = 13.sp, color = Color.LightGray)
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            AllPalettes.forEach { option ->
                val isSelected = option.key == profile.theme
                val ringAlpha by animateFloatAsState(
                    targetValue = if (isSelected) 1f else 0.25f,
                    animationSpec = tween(300),
                    label = "ThemeRing"
                )
                val dotScale by animateFloatAsState(
                    targetValue = if (isSelected) 1.15f else 1f,
                    animationSpec = tween(300),
                    label = "ThemeDotScale"
                )
                Box(
                    modifier = Modifier
                        .size((36 * dotScale).dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(option.primary, option.secondary)))
                        .border(3.dp, Color.White.copy(alpha = ringAlpha), CircleShape)
                        .clickable { vm.setTheme(option.key) }
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SentenceText(s: GeneratedSentence?) {
    val palette = LocalNeonPalette.current
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (s == null) {
            Text(text = "...", fontSize = 26.sp, color = Color.White.copy(alpha = 0.5f))
        } else {
            Text(
                text = s.en,
                style = TextStyle(
                    textDirection = TextDirection.Ltr,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = s.grammarTopic,
                fontSize = 12.sp,
                color = palette.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(palette.primary.copy(alpha = 0.14f))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
    }
}
