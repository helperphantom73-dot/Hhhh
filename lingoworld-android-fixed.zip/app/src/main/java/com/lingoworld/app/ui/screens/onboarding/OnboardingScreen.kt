package com.lingoworld.app.ui.screens.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.components.BubbleButton
import com.lingoworld.app.ui.components.GlassCard
import com.lingoworld.app.ui.components.LumoState
import com.lingoworld.app.ui.components.LumoView
import com.lingoworld.app.ui.theme.LocalNeonPalette
import com.lingoworld.app.util.toFaDigits
import kotlin.math.roundToInt

private const val TOTAL_STEPS = 6

private data class InterestOption(val key: String, val label: String, val emoji: String)

private val interestOptions = listOf(
    InterestOption("cooking", "آشپزی", "🍳"),
    InterestOption("travel", "سفر", "✈️"),
    InterestOption("tech", "فناوری", "💻"),
    InterestOption("sports", "ورزش", "⚽"),
    InterestOption("music", "موسیقی", "🎵"),
    InterestOption("nature", "طبیعت", "🌿")
)

@Composable
fun OnboardingScreen(
    onComplete: (name: String, age: Int, level: String, interests: Set<String>) -> Unit
) {
    val palette = LocalNeonPalette.current
    val focusManager = LocalFocusManager.current

    var step by rememberSaveable { mutableStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf(18) }
    var level by rememberSaveable { mutableStateOf("A1") }
    var interestsCsv by rememberSaveable { mutableStateOf("cooking") }

    val selected: Set<String> = interestsCsv.split(",").filter { it.isNotEmpty() }.toSet()

    fun toggleInterest(key: String) {
        val current = selected.toMutableSet()
        if (key in current) {
            if (current.size > 1) current.remove(key)
        } else {
            current.add(key)
        }
        interestsCsv = current.joinToString(",")
    }

    BackHandler(enabled = step > 0) { step -= 1 }

    val lumoState = when (step) {
        0 -> LumoState.HAPPY
        1 -> LumoState.THINKING
        2 -> LumoState.IDLE
        3 -> LumoState.ENCOURAGE
        4 -> LumoState.HAPPY
        else -> LumoState.CELEBRATE
    }
    val lumoText = when (step) {
        0 -> "سلام! من لومو هستم ✦"
        1 -> "اسمت چیه؟"
        2 -> "چند سالته؟"
        3 -> "انگلیسی‌ات در چه حدیه؟"
        4 -> "به چی علاقه داری؟"
        else -> "آماده‌ای شروع کنیم؟"
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
    ) {
        val minHeight = maxHeight
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = minHeight)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StepDots(current = step, total = TOTAL_STEPS)
            Spacer(modifier = Modifier.height(16.dp))

            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 22.dp) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Lumo lives outside the step transition so his idle animation never restarts.
                    LumoView(state = lumoState, speechText = lumoText)
                    Spacer(modifier = Modifier.height(16.dp))

                    AnimatedContent(
                        targetState = step,
                        transitionSpec = {
                            // RTL: moving forward brings the next page in from the left.
                            val dir = if (targetState > initialState) -1 else 1
                            (slideInHorizontally(tween(380)) { dir * it / 3 } + fadeIn(tween(380))) togetherWith
                                (slideOutHorizontally(tween(300)) { -dir * it / 3 } + fadeOut(tween(200)))
                        },
                        label = "OnboardingStep"
                    ) { currentStep ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            when (currentStep) {
                                0 -> {
                                    StepTitle("به LingoWorld خوش اومدی!")
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "یادگیری انگلیسی بر اساس علایق شما، کاملاً آفلاین و هوشمند",
                                        fontSize = 14.sp,
                                        color = Color.LightGray,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    BubbleButton(
                                        text = "شروع ماجراجویی",
                                        onClick = { step = 1 },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }

                                1 -> {
                                    StepTitle("نام شما")
                                    Spacer(modifier = Modifier.height(12.dp))
                                    OutlinedTextField(
                                        value = name,
                                        onValueChange = { if (it.length <= 20) name = it },
                                        placeholder = { Text("نام خود را بنویسید...") },
                                        singleLine = true,
                                        shape = RoundedCornerShape(16.dp),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = {
                                            if (name.isNotBlank()) {
                                                focusManager.clearFocus()
                                                step = 2
                                            }
                                        }),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            cursorColor = palette.primary,
                                            focusedBorderColor = palette.primary,
                                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                            focusedPlaceholderColor = Color.White.copy(alpha = 0.5f),
                                            unfocusedPlaceholderColor = Color.White.copy(alpha = 0.5f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))
                                    NavRow(
                                        onBack = { focusManager.clearFocus(); step = 0 },
                                        onNext = { focusManager.clearFocus(); step = 2 },
                                        nextEnabled = name.isNotBlank()
                                    )
                                }

                                2 -> {
                                    StepTitle("سن شما")
                                    Spacer(modifier = Modifier.height(8.dp))
                                    AnimatedContent(
                                        targetState = age,
                                        transitionSpec = {
                                            if (targetState > initialState) {
                                                (slideInVertically(tween(180)) { -it } + fadeIn(tween(180))) togetherWith
                                                    (slideOutVertically(tween(180)) { it } + fadeOut(tween(120)))
                                            } else {
                                                (slideInVertically(tween(180)) { it } + fadeIn(tween(180))) togetherWith
                                                    (slideOutVertically(tween(180)) { -it } + fadeOut(tween(120)))
                                            }
                                        },
                                        label = "AgeNumber"
                                    ) { value ->
                                        Text(
                                            text = value.toFaDigits(),
                                            fontSize = 48.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = palette.primary
                                        )
                                    }
                                    Slider(
                                        value = age.toFloat(),
                                        onValueChange = { age = it.roundToInt() },
                                        valueRange = 5f..99f,
                                        colors = SliderDefaults.colors(
                                            thumbColor = palette.primary,
                                            activeTrackColor = palette.primary,
                                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    NavRow(onBack = { step = 1 }, onNext = { step = 3 })
                                }

                                3 -> {
                                    StepTitle("سطح انگلیسی شما")
                                    Spacer(modifier = Modifier.height(12.dp))
                                    ChoiceCard(
                                        title = "A1 — مبتدی",
                                        subtitle = "جمله‌های ساده با فعل‌های روزمره",
                                        selected = level == "A1",
                                        onClick = { level = "A1" }
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    ChoiceCard(
                                        title = "A2 — پایه",
                                        subtitle = "گذشته‌ی ساده و جمله‌های متنوع‌تر",
                                        selected = level == "A2",
                                        onClick = { level = "A2" }
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))
                                    NavRow(onBack = { step = 2 }, onNext = { step = 4 })
                                }

                                4 -> {
                                    StepTitle("علاقه‌مندی‌های شما")
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "یک یا چند مورد را انتخاب کنید",
                                        fontSize = 13.sp,
                                        color = Color.LightGray
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    interestOptions.chunked(2).forEach { rowItems ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            rowItems.forEach { option ->
                                                InterestChip(
                                                    option = option,
                                                    selected = option.key in selected,
                                                    onClick = { toggleInterest(option.key) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    NavRow(onBack = { step = 3 }, onNext = { step = 5 })
                                }

                                else -> {
                                    StepTitle("همه‌چیز آماده‌ست، ${name.trim()}! ✨")
                                    Spacer(modifier = Modifier.height(20.dp))
                                    BubbleButton(
                                        text = "ورود به دنیای زبان",
                                        onClick = {
                                            onComplete(name.trim(), age, level, selected)
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    BubbleButton(
                                        text = "بازگشت",
                                        onClick = { step = 4 },
                                        outlined = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepTitle(text: String) {
    Text(
        text = text,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        textAlign = TextAlign.Center
    )
}

@Composable
private fun NavRow(
    onBack: () -> Unit,
    onNext: () -> Unit,
    nextEnabled: Boolean = true,
    nextText: String = "بعدی"
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BubbleButton(
            text = "بازگشت",
            onClick = onBack,
            outlined = true,
            modifier = Modifier.weight(1f)
        )
        BubbleButton(
            text = nextText,
            onClick = onNext,
            enabled = nextEnabled,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StepDots(current: Int, total: Int) {
    val palette = LocalNeonPalette.current
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until total) {
            val dotWidth by animateDpAsState(
                targetValue = if (i == current) 26.dp else 8.dp,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
                label = "DotWidth"
            )
            val dotColor by animateColorAsState(
                targetValue = if (i <= current) palette.primary else Color.White.copy(alpha = 0.2f),
                animationSpec = tween(300),
                label = "DotColor"
            )
            Box(
                modifier = Modifier
                    .width(dotWidth)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalNeonPalette.current
    val shape = RoundedCornerShape(18.dp)
    val borderColor by animateColorAsState(
        targetValue = if (selected) palette.primary else Color.White.copy(alpha = 0.15f),
        animationSpec = tween(250),
        label = "ChoiceBorder"
    )
    val fillColor by animateColorAsState(
        targetValue = if (selected) palette.primary.copy(alpha = 0.14f) else Color.White.copy(alpha = 0.06f),
        animationSpec = tween(250),
        label = "ChoiceFill"
    )
    val cardScale by animateFloatAsState(
        targetValue = if (selected) 1.02f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 400f),
        label = "ChoiceScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = cardScale
                scaleY = cardScale
            }
            .clip(shape)
            .background(fillColor, shape)
            .border(if (selected) 2.dp else 1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Column {
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 13.sp, color = Color.LightGray)
        }
    }
}

@Composable
private fun InterestChip(
    option: InterestOption,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalNeonPalette.current
    val shape = RoundedCornerShape(16.dp)
    val borderColor by animateColorAsState(
        targetValue = if (selected) palette.primary else Color.White.copy(alpha = 0.15f),
        animationSpec = tween(250),
        label = "ChipBorder"
    )
    val fillColor by animateColorAsState(
        targetValue = if (selected) palette.primary.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.06f),
        animationSpec = tween(250),
        label = "ChipFill"
    )
    val chipScale by animateFloatAsState(
        targetValue = if (selected) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 450f),
        label = "ChipScale"
    )

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = chipScale
                scaleY = chipScale
            }
            .clip(shape)
            .background(fillColor, shape)
            .border(if (selected) 2.dp else 1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "${option.emoji}  ${option.label}",
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = Color.White,
            textAlign = TextAlign.Center
        )
    }
}
