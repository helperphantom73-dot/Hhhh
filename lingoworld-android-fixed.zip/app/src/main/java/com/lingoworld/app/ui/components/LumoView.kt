package com.lingoworld.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.theme.LocalNeonPalette
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val TWO_PI = (2.0 * PI).toFloat()
private val HALF_TURN = PI.toFloat()
private val EyeColor = Color(0xFF060A17)

enum class LumoState {
    IDLE, HAPPY, THINKING, ENCOURAGE, CELEBRATE, SLEEPY
}

@Composable
fun LumoView(
    modifier: Modifier = Modifier,
    state: LumoState = LumoState.IDLE,
    stage: Int = 1,
    size: Dp = 140.dp,
    speechText: String? = null
) {
    val palette = LocalNeonPalette.current

    // Eye blink: every 2.5 to 5.5 s, eyes close for 130 ms
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2500, 5500))
            isBlinking = true
            delay(130)
            isBlinking = false
        }
    }
    val eyeOpen by animateFloatAsState(
        targetValue = if (isBlinking || state == LumoState.SLEEPY) 0.08f else 1f,
        animationSpec = tween(90),
        label = "LumoEyeOpen"
    )

    // Two clocks: a slow one (breathing, floating) and a fast one (bounces, sparkles).
    // They are read only inside graphicsLayer / Canvas, so animating never recomposes.
    val transition = rememberInfiniteTransition(label = "LumoMotion")
    val slow by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "LumoSlow"
    )
    val fast by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "LumoFast"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LumoSpeech(speechText)

        Canvas(
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    val s = sin(TWO_PI * slow)
                    var sx = 1f + 0.025f * s
                    var sy = 1f + 0.04f * s
                    var ty = -3.dp.toPx() * s
                    var rot = 0f
                    when (state) {
                        LumoState.HAPPY -> {
                            ty -= abs(sin(HALF_TURN * fast)) * 8.dp.toPx()
                        }
                        LumoState.CELEBRATE -> {
                            ty -= abs(sin(HALF_TURN * fast)) * 18.dp.toPx()
                            rot = 8f * sin(TWO_PI * fast)
                        }
                        LumoState.THINKING -> {
                            rot = 7f * sin(TWO_PI * slow)
                        }
                        LumoState.ENCOURAGE -> {
                            rot = 5f * sin(TWO_PI * fast)
                        }
                        LumoState.SLEEPY -> {
                            sx = 1f + 0.015f * s
                            sy = 1f + 0.02f * s
                            ty = 2.dp.toPx()
                        }
                        LumoState.IDLE -> Unit
                    }
                    translationY = ty
                    rotationZ = rot
                    scaleX = sx
                    scaleY = sy
                    transformOrigin = TransformOrigin(0.5f, 0.9f)
                }
        ) {
            // NOTE: inside DrawScope always use this.size (the function parameter `size` is a Dp).
            val u = this.size.minDimension
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f + u * 0.04f
            val center = Offset(cx, cy)
            val r = u * 0.32f
            val sl = sin(TWO_PI * slow)
            val happy = state == LumoState.HAPPY || state == LumoState.CELEBRATE

            // 1. Pulsing neon glow
            val glowR = r * (1.45f + 0.06f * sl)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(palette.primary.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = glowR
                ),
                radius = glowR,
                center = center
            )

            // 2. Antenna (stage 2+), tip pulses
            if (stage >= 2) {
                val tip = Offset(cx + u * 0.03f * sl, cy - r * 1.38f)
                drawLine(
                    color = palette.primary,
                    start = Offset(cx, cy - r * 0.92f),
                    end = tip,
                    strokeWidth = u * 0.025f,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White,
                    radius = u * 0.03f * (1f + 0.25f * sin(TWO_PI * fast)),
                    center = tip
                )
            }

            // 3. Body
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        palette.primary.copy(alpha = 0.55f),
                        palette.secondary.copy(alpha = 0.35f),
                        palette.tertiary.copy(alpha = 0.15f)
                    ),
                    center = Offset(cx - r * 0.25f, cy - r * 0.35f),
                    radius = r * 1.4f
                ),
                radius = r,
                center = center
            )

            // 4. Rim light
            drawCircle(
                color = Color.White.copy(alpha = 0.6f),
                radius = r,
                center = center,
                style = Stroke(width = u * 0.014f)
            )

            // 5. Specular highlight
            drawOval(
                color = Color.White.copy(alpha = 0.75f),
                topLeft = Offset(cx - r * 0.55f, cy - r * 0.65f),
                size = Size(r * 0.45f, r * 0.25f)
            )

            // 6. Blush when happy
            if (happy) {
                drawOval(
                    color = Color(0xFFFF7AC6).copy(alpha = 0.28f),
                    topLeft = Offset(cx - r * 0.76f, cy + r * 0.2f),
                    size = Size(r * 0.28f, r * 0.16f)
                )
                drawOval(
                    color = Color(0xFFFF7AC6).copy(alpha = 0.28f),
                    topLeft = Offset(cx + r * 0.48f, cy + r * 0.2f),
                    size = Size(r * 0.28f, r * 0.16f)
                )
            }

            // 7. Eyes
            val eyeY = cy - r * 0.05f
            val eyeW = r * 0.28f
            val eyeH = r * 0.40f
            val spacing = r * 0.42f
            val lookX = sin(TWO_PI * slow) * eyeW * 0.12f
            for (side in 0..1) {
                val ex = if (side == 0) cx - spacing else cx + spacing
                if (happy) {
                    // ^ ^ eyes
                    drawArc(
                        color = EyeColor,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(ex - eyeW / 2f, eyeY - eyeH * 0.1f),
                        size = Size(eyeW, eyeH * 0.55f),
                        style = Stroke(width = u * 0.03f, cap = StrokeCap.Round)
                    )
                } else {
                    val h = (eyeH * eyeOpen).coerceAtLeast(u * 0.012f)
                    drawOval(
                        color = EyeColor,
                        topLeft = Offset(ex - eyeW / 2f, eyeY - h / 2f),
                        size = Size(eyeW, h)
                    )
                    if (eyeOpen > 0.5f) {
                        drawCircle(
                            color = Color.White,
                            radius = eyeW * 0.22f,
                            center = Offset(ex - eyeW * 0.12f + lookX, eyeY - eyeH * 0.1f)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.8f),
                            radius = eyeW * 0.1f,
                            center = Offset(ex + eyeW * 0.15f + lookX, eyeY + eyeH * 0.12f)
                        )
                    }
                }
            }

            // 8. Mouth
            val mouthY = cy + r * 0.32f
            when (state) {
                LumoState.HAPPY, LumoState.CELEBRATE -> {
                    drawArc(
                        color = EyeColor,
                        startAngle = 0f,
                        sweepAngle = 180f,
                        useCenter = true,
                        topLeft = Offset(cx - r * 0.22f, mouthY - r * 0.1f),
                        size = Size(r * 0.44f, r * 0.3f)
                    )
                }
                LumoState.THINKING -> {
                    drawOval(
                        color = Color.White.copy(alpha = 0.9f),
                        topLeft = Offset(cx + r * 0.05f, mouthY),
                        size = Size(r * 0.14f, r * 0.12f),
                        style = Stroke(width = u * 0.02f)
                    )
                }
                LumoState.SLEEPY -> {
                    drawLine(
                        color = Color.White,
                        start = Offset(cx - r * 0.1f, mouthY + r * 0.05f),
                        end = Offset(cx + r * 0.1f, mouthY + r * 0.05f),
                        strokeWidth = u * 0.022f,
                        cap = StrokeCap.Round
                    )
                }
                else -> {
                    drawArc(
                        color = Color.White,
                        startAngle = 20f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.2f, mouthY - r * 0.1f),
                        size = Size(r * 0.4f, r * 0.25f),
                        style = Stroke(width = u * 0.025f, cap = StrokeCap.Round)
                    )
                }
            }

            // 9. "Thinking" dots floating up and to the side
            if (state == LumoState.THINKING) {
                for (i in 0..2) {
                    val a = 0.3f + 0.7f * (0.5f + 0.5f * sin(TWO_PI * (fast - i * 0.2f)))
                    drawCircle(
                        color = Color.White.copy(alpha = a),
                        radius = u * (0.018f + i * 0.008f),
                        center = Offset(cx + r * (0.8f + i * 0.28f), cy - r * (0.9f + i * 0.14f))
                    )
                }
            }

            // 10. Orbiting sparkles when celebrating
            if (state == LumoState.CELEBRATE) {
                for (i in 0 until 6) {
                    val ang = TWO_PI * (slow + i / 6f)
                    val orbit = r * (1.65f + 0.1f * sin(TWO_PI * (fast + i / 6f)))
                    val p = Offset(cx + cos(ang) * orbit, cy + sin(ang) * orbit)
                    val a = 0.5f + 0.5f * sin(TWO_PI * (fast + i / 6f))
                    val arm = u * 0.035f * (0.6f + 0.4f * a)
                    val col = (if (i % 2 == 0) Color.White else palette.tertiary).copy(alpha = 0.4f + 0.6f * a)
                    drawLine(col, Offset(p.x - arm, p.y), Offset(p.x + arm, p.y), strokeWidth = u * 0.012f, cap = StrokeCap.Round)
                    drawLine(col, Offset(p.x, p.y - arm), Offset(p.x, p.y + arm), strokeWidth = u * 0.012f, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun LumoSpeech(text: String?) {
    AnimatedContent(
        targetState = text ?: "",
        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
        label = "LumoSpeech"
    ) { value ->
        if (value.isNotEmpty()) {
            SpeechBubble(value)
        } else {
            Spacer(modifier = Modifier.height(1.dp))
        }
    }
}

@Composable
private fun SpeechBubble(text: String) {
    // Typewriter effect: unrevealed characters are transparent, so the bubble never resizes.
    var shown by remember(text) { mutableIntStateOf(0) }
    LaunchedEffect(text) {
        for (i in 1..text.length) {
            shown = i
            delay(26)
        }
    }
    val revealed = buildAnnotatedString {
        append(text.take(shown))
        withStyle(SpanStyle(color = Color.Transparent)) {
            append(text.drop(shown))
        }
    }

    val shape = RoundedCornerShape(18.dp)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(shape)
                .background(Color.White.copy(alpha = 0.14f), shape)
                .border(1.dp, Color.White.copy(alpha = 0.28f), shape)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                text = revealed,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
        Canvas(modifier = Modifier.size(width = 14.dp, height = 7.dp)) {
            val w = this.size.width
            val h = this.size.height
            val path = Path().apply {
                moveTo(0f, 0f)
                lineTo(w, 0f)
                lineTo(w / 2f, h)
                close()
            }
            drawPath(path = path, color = Color.White.copy(alpha = 0.14f))
        }
    }
}
