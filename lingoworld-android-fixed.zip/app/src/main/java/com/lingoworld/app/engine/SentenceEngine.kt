package com.lingoworld.app.engine

import com.lingoworld.app.data.model.Template
import com.lingoworld.app.data.model.Word

data class GeneratedSentence(
    val id: String,
    val en: String,
    val fa: String,
    val audioText: String,
    val targetWordIds: List<String>,
    val grammarTopic: String,
    val fingerprint: String
)

class SentenceEngine(
    private val allWords: List<Word>,
    private val allTemplates: List<Template>,
    private val isSentenceSeen: suspend (String) -> Boolean
) {
    private val levelOrder = listOf("A1", "A2", "B1", "B2", "C1")

    /**
     * Builds a fresh sentence for [topic]. Uses every template up to and including [level],
     * so reviewing easier grammar is mixed in. Returns null if nothing unseen could be built
     * (unless [allowRepeats] is true).
     */
    suspend fun generateSentence(
        level: String,
        topic: String,
        allowRepeats: Boolean = false
    ): GeneratedSentence? {
        val maxIndex = levelOrder.indexOf(level).coerceAtLeast(0)
        val templates = allTemplates.filter { levelOrder.indexOf(it.level) in 0..maxIndex }

        val topicWords = allWords.filter { topic in it.topics }
        val verbs = topicWords.filter { it.pos == "verb" }
        val nouns = topicWords.filter { it.pos == "noun" }

        val pairs = verbs.flatMap { v ->
            nouns.filter { n -> accepts(v, n) }.map { n -> v to n }
        }
        if (templates.isEmpty() || pairs.isEmpty()) return null

        for (attempt in 0 until 40) {
            val tpl = templates.random()
            val (verb, obj) = pairs.random()
            val sentence = build(tpl, verb, obj) ?: continue
            if (allowRepeats || !isSentenceSeen(sentence.fingerprint)) return sentence
        }
        return null
    }

    private fun accepts(verb: Word, noun: Word): Boolean =
        verb.acceptsObjectTags.isEmpty() || noun.tags.any { it in verb.acceptsObjectTags }

    private fun build(tpl: Template, verb: Word, obj: Word): GeneratedSentence? {
        val article = if (obj.countable) GrammarUtils.getIndefiniteArticle(obj.en) else "some"
        val faArticle = if (obj.countable) "یک" else "کمی"

        val en = tpl.pattern
            .replace("{V:3sg}", GrammarUtils.conjugate3sg(verb.en))
            .replace("{V:past}", GrammarUtils.pastTense(verb.en, verb.irregular))
            .replace("{V}", verb.en)
            .replace("{O}", obj.en)
            .replace("{ART}", article)

        val forms = verb.faForms
        val fa = tpl.faPattern
            .replace("{FV1}", forms?.present1 ?: verb.fa)
            .replace("{FV3}", forms?.present3 ?: verb.fa)
            .replace("{FP1}", forms?.past1 ?: verb.fa)
            .replace("{FP3}", forms?.past3 ?: verb.fa)
            .replace("{O}", obj.fa)
            .replace("{ART}", faArticle)

        // Safety net: never show a sentence with an unresolved placeholder.
        if (en.contains('{') || fa.contains('{')) return null

        val usesVerb = tpl.pattern.contains("{V")
        val fingerprint = if (usesVerb) "${tpl.id}_${verb.id}_${obj.id}" else "${tpl.id}_${obj.id}"
        val targets = if (usesVerb) listOf(verb.id, obj.id) else listOf(obj.id)

        return GeneratedSentence(
            id = "$fingerprint#${System.nanoTime()}",
            en = en,
            fa = fa,
            audioText = en,
            targetWordIds = targets,
            grammarTopic = tpl.grammarTopic,
            fingerprint = fingerprint
        )
    }
}
