package com.lingoworld.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lingoworld.app.data.SampleData
import com.lingoworld.app.data.datastore.UserPreferences
import com.lingoworld.app.data.datastore.UserProfile
import com.lingoworld.app.data.room.DailyStatEntity
import com.lingoworld.app.data.room.LingoDatabase
import com.lingoworld.app.data.room.SeenSentenceEntity
import com.lingoworld.app.data.room.WordProgressEntity
import com.lingoworld.app.engine.GeneratedSentence
import com.lingoworld.app.engine.SentenceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = UserPreferences(application)
    private val dao = LingoDatabase.getDatabase(application).lingoDao()

    private val engine = SentenceEngine(
        allWords = SampleData.words,
        allTemplates = SampleData.templates,
        isSentenceSeen = { fingerprint -> dao.isSentenceSeen(fingerprint) > 0 }
    )

    val profile: StateFlow<UserProfile> = prefs.profile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = UserProfile()
    )

    private val _sentence = MutableStateFlow<GeneratedSentence?>(null)
    val sentence: StateFlow<GeneratedSentence?> = _sentence.asStateFlow()

    private val learnedIds = mutableSetOf<String>()

    fun completeOnboarding(name: String, age: Int, level: String, interests: Set<String>) {
        viewModelScope.launch { prefs.saveProfile(name, age, level, interests) }
    }

    fun setTheme(key: String) {
        viewModelScope.launch { prefs.setTheme(key) }
    }

    fun nextSentence() {
        val p = profile.value
        if (p.interests.isEmpty()) return
        viewModelScope.launch {
            val topic = p.interests.random()
            var result = engine.generateSentence(p.level, topic)
            if (result == null) {
                // Everything for this topic was already seen: allow repeats instead of showing nothing.
                result = engine.generateSentence(p.level, topic, allowRepeats = true)
            }
            if (result != null) {
                _sentence.value = result
                dao.insertSeenSentence(SeenSentenceEntity(fingerprint = result.fingerprint))
                if (dao.getSeenCount() > 5000) dao.trimOldSeenSentences(keep = 2000)
            }
        }
    }

    /** Called when the learner taps "I got it". Awards XP once per sentence. */
    fun markLearned() {
        val s = _sentence.value ?: return
        if (!learnedIds.add(s.id)) return
        viewModelScope.launch {
            prefs.addXp(XP_PER_SENTENCE)

            val today = LocalDate.now().toString()
            val stat = dao.getDailyStat(today) ?: DailyStatEntity(date = today)
            dao.saveDailyStat(stat.copy(xp = stat.xp + XP_PER_SENTENCE, correct = stat.correct + 1))

            val now = System.currentTimeMillis()
            for (wordId in s.targetWordIds) {
                val cur = dao.getWordProgress(wordId) ?: WordProgressEntity(wordId = wordId)
                dao.saveWordProgress(
                    cur.copy(
                        mastery = (cur.mastery + 10).coerceAtMost(100),
                        box = if (cur.mastery >= 50) (cur.box + 1).coerceAtMost(5) else cur.box,
                        lastSeen = now,
                        correctCount = cur.correctCount + 1
                    )
                )
            }
        }
    }

    companion object {
        const val XP_PER_SENTENCE = 10
    }
}
