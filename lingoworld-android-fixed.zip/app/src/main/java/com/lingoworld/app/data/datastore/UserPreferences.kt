package com.lingoworld.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(name = "user_preferences")

/** Immutable snapshot of everything stored about the user. */
data class UserProfile(
    val loaded: Boolean = false,
    val onboardingDone: Boolean = false,
    val name: String = "",
    val age: Int = 18,
    val level: String = "A1",
    val interests: Set<String> = setOf("cooking"),
    val xp: Int = 0,
    val theme: String = "neon-blue",
    val ttsSpeed: Float = 0.9f
)

class UserPreferences(private val context: Context) {
    companion object {
        val KEY_NAME = stringPreferencesKey("user_name")
        val KEY_AGE = intPreferencesKey("user_age")
        val KEY_LEVEL = stringPreferencesKey("user_reported_level")
        val KEY_INTERESTS = stringSetPreferencesKey("user_interests")
        val KEY_XP = intPreferencesKey("user_xp")
        val KEY_STREAK = intPreferencesKey("user_streak")
        val KEY_THEME = stringPreferencesKey("app_theme")
        val KEY_GRAPHIC_TIER = stringPreferencesKey("app_graphic_tier")
        val KEY_TTS_SPEED = floatPreferencesKey("tts_speed")
        val KEY_REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val KEY_ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
    }

    private val safeData = context.dataStore.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val profile: Flow<UserProfile> = safeData.map { p ->
        UserProfile(
            loaded = true,
            onboardingDone = p[KEY_ONBOARDING_DONE] ?: false,
            name = p[KEY_NAME] ?: "",
            age = p[KEY_AGE] ?: 18,
            level = p[KEY_LEVEL] ?: "A1",
            interests = (p[KEY_INTERESTS] ?: setOf("cooking")).ifEmpty { setOf("cooking") },
            xp = p[KEY_XP] ?: 0,
            theme = p[KEY_THEME] ?: "neon-blue",
            ttsSpeed = p[KEY_TTS_SPEED] ?: 0.9f
        )
    }

    val userStreak: Flow<Int> = safeData.map { it[KEY_STREAK] ?: 1 }
    val graphicTier: Flow<String> = safeData.map { it[KEY_GRAPHIC_TIER] ?: "high" }
    val reminderHour: Flow<Int> = safeData.map { it[KEY_REMINDER_HOUR] ?: 20 }

    suspend fun saveProfile(name: String, age: Int, level: String, interests: Set<String>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_NAME] = name
            prefs[KEY_AGE] = age
            prefs[KEY_LEVEL] = level
            prefs[KEY_INTERESTS] = interests
            prefs[KEY_ONBOARDING_DONE] = true
        }
    }

    suspend fun addXp(amount: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_XP] = (prefs[KEY_XP] ?: 0) + amount
        }
    }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { prefs -> prefs[KEY_THEME] = theme }
    }

    suspend fun setGraphicTier(tier: String) {
        context.dataStore.edit { prefs -> prefs[KEY_GRAPHIC_TIER] = tier }
    }
}
