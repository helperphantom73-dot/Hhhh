package com.lingoworld.app.util

/** Converts Latin digits to Persian digits (۰-۹). */
fun Int.toFaDigits(): String = this.toString().toFaDigits()

fun String.toFaDigits(): String = buildString(length) {
    for (c in this@toFaDigits) {
        append(if (c in '0'..'9') '۰' + (c - '0') else c)
    }
}
