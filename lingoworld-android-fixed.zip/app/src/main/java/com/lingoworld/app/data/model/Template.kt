package com.lingoworld.app.data.model

data class Template(
    val id: String,
    val level: String,
    val pattern: String,
    val faPattern: String,
    val grammarTopic: String,
    val minAge: Int = 5,
    val slots: List<SlotDefinition> = emptyList()
)

data class SlotDefinition(
    val name: String,
    val pos: String,
    val isSubject: Boolean = false,
    val isObject: Boolean = false,
    val tense: String? = null, // base, 3sg, past, pastParticiple, ing
    val number: String? = null // singular, plural
)
