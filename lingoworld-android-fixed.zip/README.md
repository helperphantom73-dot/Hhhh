# LingoWorld — دنیای زبان

اپ آموزش انگلیسی (Kotlin + Jetpack Compose) با انیمیشن‌های نئونی، شخصیت «لومو» و جمله‌سازی آفلاین.

## ساخت APK با GitHub Actions
1. یک مخزن جدید بسازید.
2. دو فایل را در مخزن قرار دهید:
   - همین zip در **ریشه‌ی** مخزن
   - فایل `build-apk.yml` در مسیر `.github/workflows/build-apk.yml`
3. تب **Actions** را باز کنید؛ ساخت خودکار شروع می‌شود (یا Run workflow).
4. در پایین صفحه‌ی run، بخش **Artifacts** ← فایل **LingoWorld-APK** را دانلود کنید.

## ساخت روی کامپیوتر
`./gradlew assembleDebug`  ← خروجی: `app/build/outputs/apk/debug/app-debug.apk`
